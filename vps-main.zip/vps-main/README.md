
# Free RDP 6 HOURS



### HOW TO CREATE
```
> Press the Fork button to create RDP (For Android / HP Users, Please Use Desktop Mode).

> visit https://dashboard.ngrok.com to get NGROK_AUTH_TOKEN

> Inside this Repo Go to Settings> Secrets> New repository secret

> Fill in the Name: Enter NGROK_AUTH_TOKEN

> Fill in Value: Visit https://dashboard.ngrok.com/auth/your-authtoken Copy and Paste in the value

> Press Add secret 

> Go to Action> CI> Run workflow

> Refresh Web and go to CI> build

> Press Down facing arrow button "RDP INFO LOGIN" To Get IP, User, Password.
```
## Video
[![VPS_RDP_Github](https://www.youtube.com/s/desktop/f7d4cb0d/img/favicon_144x144.png)](https://youtu.be/H-cbUgKNeI8)
### WARN
THIS IS ONLY FOR EDUCATIONAL PURPOSES DON'T USE FOR MINING OR ILLEGAL USE
